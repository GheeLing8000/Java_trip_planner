package com.acwd.iu7;
import java.util.*;

public class OddOrEven {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        //intro: TODO 1_Call introduction method//
        intro();
        //take in the users name, odd or evens

        //randomizer : TOD0 2_Call  the random function//
        //sum
        //adds the 2 integers together and produces the sum

        //who wins :TODO3 :Call the winnet function//
        //decided whether the final answer is even or odd and declares a winner.
        //if ( user is odd and  sum is odd){
           // user wins}
        //else if (user is odd and sum is even){
           // user loses
       // }



    }
    public static void intro() {
        /**TODO 1.1 : Create the intro class*/
        System.out.println("Let's play a game called \"Odds and Evens\"");
        System.out.print("What is your name?");
        Scanner scName = new Scanner(System.in);
        String userName = scName.nextLine();
        System.out.print("Hi ," + userName + " Which do you choose? (O)dds or (E)vens");
        Scanner scChoice = new Scanner(System.in);
        String userChoice = scChoice.nextLine();
        if (userChoice.equals("O")) {
            System.out.println(userName + " has picked odds! The computer will be evens.");
            System.out.print("---------------------------\n");
        } else if (userChoice.equals("E")) {
            System.out.println(userName + " has picked evens! The computer will be odds.");
            System.out.print("---------------------------\n");
        }

            /**TODO 2.1 : Create the play_games class*/
            System.out.print("How many \"fingers\" do you put out?");
            Scanner scFingers = new Scanner(System.in);
            Integer userNumber = scFingers.nextInt();
            //takes in the number of  "fingers"  the user would like to play, and uses
            //the random generator to decide what the computer will play
            String computerName = "computer";
            Random rand = new Random();
            int computer = rand.nextInt(6);
            Integer sum = computer + userNumber;
            System.out.println("The computer plays " + sum + " " + "\"fingers\".");
            System.out.print("---------------------------\n");
            boolean oddOrEven = sum % 2 == 0;
            if (oddOrEven == true && userNumber % 2 == 0) {
                System.out.println("That means " + userName + " wins!  :)");
                System.out.println(+userNumber + " " + " + " + computer + " " + " = " + sum);
                System.out.print("---------------------------\n");
            } else if (oddOrEven == false && userNumber % 2 != 0) {

                System.out.println(+userNumber + " " + " + " + computer + " " + " = " + sum);
                System.out.println(+sum + " is .... odd");
                System.out.println("That means " + userName + " wins!  :)");
                System.out.print("---------------------------\n");

                } else if (oddOrEven == true && userNumber % 2 != 0) {

                System.out.println(+userNumber + " " + " + " + computer + " " + " = " + sum);
                System.out.println(+sum + " is .... odd");
                System.out.println("That means " + computerName + " wins!  :)");
                System.out.print("---------------------------\n");

            }

            else if (oddOrEven == false && userNumber % 2 == 0) {

                System.out.println(+userNumber + " " + " + " + computer + " " + " = " + sum);
                System.out.println(+sum + " is .... odd");
                System.out.println("That means " + computerName + " wins!  :)");
                System.out.print("---------------------------\n");

            }
            }
            }




