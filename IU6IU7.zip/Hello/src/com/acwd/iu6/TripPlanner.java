package com.acwd.iu6;

import java.util.Scanner;
import java.awt.*;
import java.text.DecimalFormat;

public class TripPlanner {

    public static void main(String[] args){
        /**TODO1.2 : Call greetings class*/
        greetings();
        /**TODO2.2 : Call travel Budget class*/
        travelBudget();
        /**TODO3.2 : Call timeDifference class*/
        timeDifference();
        /**TODO3.2 : Call squareArea class*/
        squareArea();

    }


    public static void greetings(){
        /**TODO 1.1 : Create the greetings class*/
        System.out.print("Welcome to Vacation Planner!\n");
        System.out.print("What is your name?");
        Scanner sc0 = new Scanner(System.in);
        String userInput = sc0.nextLine();
        System.out.print("Nice to meet you," + userInput + " where are  going?");
        Scanner sc1 = new Scanner(System.in);
        String userInputPlace = sc1.nextLine();
        System.out.print("Great!" + userInputPlace + " sounds like a great trip!\n");
        System.out.print("**************\n");

    }
    public static void travelBudget(){
        /**TODO 2.1 : Create the travel budget class*/
        System.out.print("How many days are you going to spend travelling?");
        Scanner sc2 = new Scanner(System.in);
        String userInputDays = sc2.nextLine();
        int userIntegerDays = Integer.valueOf(userInputDays);
        System.out.print("How much money, in USD, are you planning to spend on your trip?");
        Scanner sc3 = new Scanner(System.in);
        String userInputMoneyUSD = sc3.nextLine();
        int userInputIntegerMoneyUSD = Integer.valueOf(userInputMoneyUSD);
        System.out.print("What is the three letter currency symbol for your travel destination?");
        Scanner sc4 = new Scanner(System.in);
        String userInputCurrencySymbol = sc4.nextLine();
        System.out.print("How many " +  userInputCurrencySymbol + " are there in 1 USD?");
        Scanner sc5 = new Scanner(System.in);
        String userInputCurrencyExchange = sc5.nextLine();
        double userInputDoubleCurrencyExchange = Double.valueOf(userInputCurrencyExchange);
        int timeInHours = userIntegerDays*24;
        int timeInMinutes = timeInHours*60;

        System.out.print("If you are travelling for " +  userIntegerDays +
                " days that is same as " + timeInHours + " hours or " + timeInMinutes + " minutes\n");
        DecimalFormat formatter = new DecimalFormat("#0.00");
        String y = formatter.format((float)userInputIntegerMoneyUSD/userIntegerDays);
        System.out.print("If you are going to spend $" +  userInputIntegerMoneyUSD +
                " USD that means per day you can spend up to $ " + y + " USD\n");
        double userInputDoubleMoneyForeignCurrency = userInputIntegerMoneyUSD*userInputDoubleCurrencyExchange;
        String z = formatter.format(userInputDoubleMoneyForeignCurrency/userIntegerDays);
        System.out.println("Your total budget in MXC is " +  userInputDoubleMoneyForeignCurrency + " " +
                userInputCurrencySymbol + ", which per day is " + (z) + " " + userInputCurrencySymbol);
        System.out.print("**********\n");
    }
    public static  void timeDifference() {
        /**TODO 3.1 : Create the time difference class*/
        System.out.print("What is the time difference, in hours, between your home and your destination?");
        Scanner sc6 = new Scanner(System.in);
        String userInputHours = sc6.nextLine();
        int userIntegerInputHours = Integer.valueOf(userInputHours);

        int timeDifferenceMidNight = ((24  + userIntegerInputHours)%2);
        int  timeDifferenceMidNightBehindHours =  24 + userIntegerInputHours;
        int timeDifferenceNoon = 12%24 + userIntegerInputHours;
        if (userIntegerInputHours >= 0)
        {System.out.println("That means that when it is midnight at home, it will be " + timeDifferenceMidNight
                + ":00 in your travel destination and when it is noon at home, it will be " + timeDifferenceNoon
                +":00");
        System.out.print("**********\n");}
        else
        {
            {System.out.println("That means that when it is midnight at home, it will be " + timeDifferenceMidNightBehindHours
                    + ":00 in your travel destination and when it is noon at home, it will be " + timeDifferenceNoon
                    +":00");
                System.out.print("**********\n");}
        }
    }
    public static  void squareArea(){
        /**TODO 4.1 : Create the square area class*/
        System.out.print("What is the square area of your destination country in km2?");
        Scanner sc7 = new Scanner(System.in);
        String userInputSquareArea = sc7.nextLine();
        double userDoubleInputSquareArea = Double.valueOf(userInputSquareArea);
        /*TODO4.12: https://www.metric-conversions.org/area/square-kilometers-to-square-miles.htm*/
        double userDoubleInputMilesArea = userDoubleInputSquareArea*0.38610;
        System.out.print("In miles2 that is " + userDoubleInputMilesArea);
        System.out.print("*******\n");
    }
}


