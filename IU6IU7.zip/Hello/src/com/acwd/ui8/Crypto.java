package com.acwd.ui8;
import java.util.Scanner ;
import java.lang.Character;
import java.lang.String ;

public class Crypto {

    public static void main(String[] args) {
        //1.2 Call in function  normalizeText()//
        System.out.println("Type a sentence and press enter.");
        Scanner scNormText = new Scanner(System.in);
        String userInputNormText = scNormText.nextLine();

        normalizeText(userInputNormText);

        System.out.println("Type a sentence and press enter.");
        Scanner scEncryptText = new Scanner(System.in);
        String userInputEncryptText = scEncryptText.nextLine();
        System.out.println("Type a whole number and press enter.");
        Scanner scEncryptInteger = new Scanner(System.in);
        Integer userInputEncryptInteger = scEncryptInteger.nextInt();
        Cesarify(userInputEncryptText, userInputEncryptInteger);
    }

    public static String normalizeText(String a) {


        String noWhiteSpace = a.trim();
        System.out.println(noWhiteSpace);
        String noPunctuation = noWhiteSpace.replaceAll("\\W", "");
        System.out.println(noPunctuation);
        String upperCaseResult = noPunctuation.toUpperCase();
        //System.out.println(upperCaseResult);//
        return upperCaseResult;

    }
    public  static void Cesarify(String encryption, Integer encryptionkey) {

       
        //shiftAlphabet(key);//

    }
    public  static void Groupify(String group, char letters) {

        normalizeText(shiftAlphabet(1));
        //shiftAlphabet(key);//

    }

    public static String shiftAlphabet(int shift) {
        int start = 0;
        if (shift < 0) {
            start = (int) 'Z' + shift + 1;
        } else {
            start = 'A' + shift;
        }
        String result = "";
        char currChar = (char) start;
        for(; currChar <= 'Z'; ++currChar) {
            result = result + currChar;
        }
        if(result.length() < 26) {
            for(currChar = 'A'; result.length() < 26; ++currChar) {
                result = result + currChar;
            }
        }
        return result;
    }


}
