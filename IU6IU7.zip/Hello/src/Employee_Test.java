public class Employee_Test {


        public static void main(String[] args) {
            Employee emp1 = new Employee();
            //empl.id = 1;
            emp1.name = "Bob";
            System.out.println(emp1.getId());
            System.out.println(emp1.getEmpId());

            Employee emp2 = new Employee();
            //emp2.id = 2;
            emp2.name = "Charlie";
            System.out.println(emp2.getId());
            System.out.println(emp2.getEmpId());

            Employee emp3 = new Employee();
            //emp2.id = 3;
            emp3.name = "Chey";
            System.out.println(emp3.getId());
            System.out.println(emp3.getEmpId());

            System.out.println(emp1.toString());
            System.out.println(emp2.toString());
            System.out.println(emp3.toString());
        }
}
