public class Employee {
    private int id;
    public String name;

    static int empId =1;



    public Employee() {
        //Constructor method//
        id = empId;
        ++empId;
    }
        public int getId() {
            return id;
        }

    public static int getEmpId() {
        return empId;
    }

    @Override
    public String toString() {
        return "Id: " + id + "\nName: " + name;
        //return super.toString();
    }
}












